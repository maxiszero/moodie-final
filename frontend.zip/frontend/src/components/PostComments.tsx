import { useCallback, useEffect, useId, useState } from 'react'
import { createPortal } from 'react-dom'
import type { Post, PostComment } from '../types'
import { useSession } from '../state/SessionContext'
import { apiFetch } from '../api/apiClient'
import { getLang, t } from '../i18n/i18n'
import { PostText } from './PostText'

const MOBILE_MAX_PX = 640

function useNarrowScreen() {
  const [narrow, setNarrow] = useState(
    () => typeof window !== 'undefined' && window.matchMedia(`(max-width: ${MOBILE_MAX_PX}px)`).matches,
  )
  useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${MOBILE_MAX_PX}px)`)
    const f = () => setNarrow(mq.matches)
    f()
    mq.addEventListener('change', f)
    return () => mq.removeEventListener('change', f)
  }, [])
  return narrow
}

function authorName(c: PostComment) {
  const u = c.userId
  if (u && typeof u === 'object' && 'username' in u) return String((u as { username: string }).username)
  return '…'
}

function userGradient(c: PostComment) {
  const u = c.userId
  if (!u || typeof u !== 'object') return 'linear-gradient(135deg, #9E9E9E, #757575, #616161, #757575, #9E9E9E)'
  const c1 = (u as { currentColor?: string }).currentColor || '#9E9E9E'
  const c2 = (u as { currentColor2?: string }).currentColor2 || c1
  const c3 = (u as { currentColor3?: string }).currentColor3 || c2
  return `linear-gradient(135deg, ${c1}, ${c2}, ${c3}, ${c2}, ${c1})`
}

function postAuthorName(p: Post) {
  const u = p.userId
  if (u && typeof u === 'object' && 'username' in u) return String((u as { username: string }).username)
  return '…'
}

function postAuthorGradient(p: Post) {
  const u = p.userId
  if (!u || typeof u !== 'object') return 'linear-gradient(135deg, #9E9E9E, #757575, #616161, #757575, #9E9E9E)'
  const c1 = (u as { currentColor?: string }).currentColor || '#9E9E9E'
  const c2 = (u as { currentColor2?: string }).currentColor2 || c1
  const c3 = (u as { currentColor3?: string }).currentColor3 || c2
  return `linear-gradient(135deg, ${c1}, ${c2}, ${c3}, ${c2}, ${c1})`
}

function postAuthorEmoji(p: Post) {
  const u = p.userId
  if (u && typeof u === 'object' && 'currentEmoji' in u && (u as { currentEmoji?: string }).currentEmoji) {
    return String((u as { currentEmoji?: string }).currentEmoji)
  }
  return p.emoji || '😐'
}

function SheetPostPreview({ post }: { post: Post }) {
  const name = postAuthorName(post)
  const emoji = postAuthorEmoji(post)
  return (
    <div className="post-comments__sheet-post" role="article" aria-label={t('post')}>
      <a className="post-comments__sheet-post-avatar" href={`#/profile/${encodeURIComponent(name)}`} title={name}>
        <div className="user-circle user-circle--sm" style={{ background: postAuthorGradient(post) }}>
          {emoji}
        </div>
      </a>
      <div className="post-comments__sheet-post-body">
        <div className="post-comments__sheet-post-meta">
          <a className="post-comments__sheet-post-author" href={`#/profile/${encodeURIComponent(name)}`}>
            {name}
          </a>
          <span className="post-comments__sheet-post-time">
            {new Date(post.createdAt).toLocaleString(getLang() === 'en' ? 'en-US' : 'ru-RU', {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>
        <div className="post-comments__sheet-post-text">
          <PostText text={post.text} />
        </div>
      </div>
    </div>
  )
}

const commentBubbleIcon = (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
  </svg>
)

type PanelProps = {
  n: number
  inlineOpen: boolean
  items: PostComment[]
  loading: boolean
  err: string
  text: string
  setText: (v: string) => void
  busy: boolean
  s: ReturnType<typeof useSession>
  onSend: () => void
  onRemove: (id: string) => void
  isSheet: boolean
  onRequestClose: () => void
}

function CommentsThread({
  n,
  inlineOpen,
  items,
  loading,
  err,
  text,
  setText,
  busy,
  s,
  onSend,
  onRemove,
  isSheet,
  onRequestClose,
}: PanelProps) {
  return (
    <>
      {n > 0 && !isSheet && inlineOpen && (
        <div className="post-comments__bar">
          <button type="button" className="post-comments__hide" onClick={onRequestClose} aria-expanded>
            {t('comments_hide')}
          </button>
        </div>
      )}

      {n > 0 && (inlineOpen || isSheet) && loading && items.length === 0 ? <div className="post-comments__status">{t('comment_loading')}</div> : null}
      {err ? <div className="post-comments__err">{err}</div> : null}
      {n > 0 && (inlineOpen || isSheet) && !loading && items.length === 0 && !err ? <p className="post-comments__empty">{t('comments_empty_list')}</p> : null}
      {n === 0 ? <p className="post-comments__hint">{t('comments_be_first')}</p> : null}

      {items.length > 0 && (
        <ul className="post-comments__list">
          {items.map((c) => {
            const name = authorName(c)
            const uid = c.userId && typeof c.userId === 'object' && '_id' in c.userId ? String((c.userId as { _id: string })._id) : ''
            const own = s.userId && uid && String(s.userId) === String(uid)
            return (
              <li key={c._id} className="post-comments__row">
                <a className="post-comments__avatar" href={`#/profile/${encodeURIComponent(name)}`} title={name}>
                  <div className="user-circle user-circle--sm" style={{ background: userGradient(c) }}>
                    {(c.userId && typeof c.userId === 'object' && (c.userId as { currentEmoji?: string }).currentEmoji) || '😐'}
                  </div>
                </a>
                <div className="post-comments__body">
                  <div className="post-comments__meta">
                    <a className="post-comments__author" href={`#/profile/${encodeURIComponent(name)}`}>
                      {name}
                    </a>
                    <span className="post-comments__time">
                      {new Date(c.createdAt).toLocaleString(getLang() === 'en' ? 'en-US' : 'ru-RU', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>
                  <div className="post-comments__text">
                    <PostText text={c.text} />
                  </div>
                </div>
                {own || s.role === 'admin' ? (
                  <button type="button" className="post-comments__remove" onClick={() => void onRemove(c._id)} title={t('comment_delete')}>
                    ×
                  </button>
                ) : null}
              </li>
            )
          })}
        </ul>
      )}

      {s.isAuthed ? (
        <div className="post-comments__composer">
          <textarea
            className="post-comments__input"
            rows={2}
            maxLength={500}
            placeholder={t('comment_placeholder')}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                e.preventDefault()
                void onSend()
              }
            }}
          />
          <div className="post-comments__send-row">
            <span className="post-comments__hint-kbd">{t('comment_shortcut_hint')}</span>
            <button type="button" className="btn-primary post-comments__send" onClick={() => void onSend()} disabled={busy || !text.trim()}>
              {busy ? t('publishing') : t('comment_send')}
            </button>
          </div>
        </div>
      ) : (
        <p className="post-comments__login-hint">{t('comments_login_hint')}</p>
      )}
    </>
  )
}

export function PostComments({
  post,
  onPostUpdated,
  onOpenChange,
  sheetTopPx,
}: {
  post: Post
  onPostUpdated: (next: Post) => void
  onOpenChange?: (open: boolean) => void
  sheetTopPx?: number | null
}) {
  const s = useSession()
  const isNarrow = useNarrowScreen()
  const sheetId = useId()
  const n = post.commentsCount ?? 0
  const [inlineOpen, setInlineOpen] = useState(false)
  const [sheetOpen, setSheetOpen] = useState(false)
  const [items, setItems] = useState<PostComment[]>([])
  const [loading, setLoading] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const [text, setText] = useState('')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')

  const showInlinePanel = n === 0 || inlineOpen

  useEffect(() => {
    if (isNarrow) {
      setInlineOpen(false)
    } else {
      setSheetOpen(false)
    }
  }, [isNarrow])

  useEffect(() => {
    onOpenChange?.(Boolean((isNarrow && sheetOpen) || (!isNarrow && inlineOpen)))
  }, [isNarrow, sheetOpen, inlineOpen, onOpenChange])

  const load = useCallback(async () => {
    setLoading(true)
    setErr('')
    try {
      const data = await apiFetch<PostComment[]>(`/posts/${post._id}/comments`)
      setItems(Array.isArray(data) ? data : [])
      setLoaded(true)
    } catch (e: unknown) {
      setItems([])
      setErr(
        e && typeof e === 'object' && 'message' in e ? String((e as { message: string }).message) : t('comment_load_error'),
      )
    } finally {
      setLoading(false)
    }
  }, [post._id])

  useEffect(() => {
    const needLoad = n > 0 && !loaded
    if (!needLoad) return
    const visible = (isNarrow && sheetOpen) || (!isNarrow && inlineOpen)
    if (visible) void load()
  }, [n, loaded, isNarrow, sheetOpen, inlineOpen, load])

  useEffect(() => {
    if (!sheetOpen) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSheetOpen(false)
    }
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = prev
      document.removeEventListener('keydown', onKey)
    }
  }, [sheetOpen])

  const send = async () => {
    const w = text.trim()
    if (!w || busy || w.length > 500) return
    setBusy(true)
    setErr('')
    try {
      const c = await apiFetch<PostComment>(`/posts/${post._id}/comments`, {
        method: 'POST',
        body: JSON.stringify({ text: w }),
      })
      setText('')
      setItems((prev) => [...prev, c])
      setLoaded(true)
      if (isNarrow) setSheetOpen(true)
      else setInlineOpen(true)
      onPostUpdated({ ...post, commentsCount: (post.commentsCount ?? 0) + 1 })
    } catch (e: unknown) {
      setErr(e && typeof e === 'object' && 'message' in e ? String((e as { message: string }).message) : t('comment_error'))
    } finally {
      setBusy(false)
    }
  }

  const remove = async (id: string) => {
    try {
      await apiFetch(`/posts/${post._id}/comments/${id}`, { method: 'DELETE' })
      setItems((prev) => prev.filter((x) => x._id !== id))
      onPostUpdated({ ...post, commentsCount: Math.max(0, (post.commentsCount ?? 0) - 1) })
    } catch {
      /* ignore */
    }
  }

  const panelArgs: PanelProps = {
    n,
    inlineOpen,
    items,
    loading,
    err,
    text,
    setText,
    busy,
    s,
    onSend: send,
    onRemove: remove,
    isSheet: isNarrow,
    onRequestClose: () => setInlineOpen(false),
  }

  if (isNarrow) {
    const showPostPreviewInSheet = !(sheetTopPx != null && sheetTopPx > 0)
    return (
      <div className="post-comments post-comments--mobile" onClick={(e) => e.stopPropagation()}>
        <button
          type="button"
          className="post-comments__action-btn"
          onClick={() => setSheetOpen(true)}
          aria-expanded={sheetOpen}
          aria-controls={sheetOpen ? sheetId : undefined}
        >
          {commentBubbleIcon}
          <span className="post-comments__action-label">{t('comments_button')}</span>
          {n > 0 ? <span className="post-comments__action-count">{n}</span> : null}
        </button>

        {sheetOpen &&
          createPortal(
            <div
              className="post-comments__sheet"
              role="dialog"
              aria-modal
              id={sheetId}
              aria-label={t('comments_sheet_title')}
              style={sheetTopPx != null && sheetTopPx > 0 ? ({ ['--comments-sheet-top' as any]: `${sheetTopPx}px` } as any) : undefined}
            >
              <button
                type="button"
                className="post-comments__sheet-backdrop"
                onClick={() => setSheetOpen(false)}
                aria-label={t('a11y_close')}
              />
              <div className="post-comments__sheet-panel">
                <div className="post-comments__sheet-header">
                  <h3 className="post-comments__sheet-title">{t('comments_sheet_title')}</h3>
                  <button type="button" className="post-comments__sheet-close" onClick={() => setSheetOpen(false)} aria-label={t('a11y_close')}>
                    ×
                  </button>
                </div>
                <div className="post-comments__sheet-scroll">
                  {showPostPreviewInSheet ? <SheetPostPreview post={post} /> : null}
                  <CommentsThread {...panelArgs} isSheet={true} />
                </div>
              </div>
            </div>,
            document.body,
          )}
      </div>
    )
  }

  return (
    <div className="post-comments" onClick={(e) => e.stopPropagation()}>
      {n > 0 && !inlineOpen && (
        <button type="button" className="post-comments__toggle" onClick={() => setInlineOpen(true)} aria-expanded={false}>
          {t('comments_show_n').replace('{n}', String(n))}
        </button>
      )}

      {showInlinePanel && (
        <div className="post-comments__panel">
          <CommentsThread {...panelArgs} isSheet={false} />
        </div>
      )}
    </div>
  )
}

import { HashRouter, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { AppHeader } from './layout/AppHeader'
import { AppFooter } from './layout/AppFooter'
import { FeedPage } from './routes/FeedPage'
import { SettingsPage } from './routes/SettingsPage'
import { AdminPage } from './routes/AdminPage'
import { ProfilePage } from './routes/ProfilePage'
import { AuthPage } from './routes/AuthPage'
import { TestsHubPage } from './routes/tests/TestsHubPage'
import { EmotionTestPage } from './routes/tests/EmotionTestPage'
import { MbtiTestPage } from './routes/tests/MbtiTestPage'
import { SearchPage } from './routes/SearchPage'
import { useSession } from './state/SessionContext'
import { FeedMoodProvider } from './state/FeedMoodContext'
import { useEffect, useState } from 'react'
import { WelcomeModal } from './components/WelcomeModal'
import { Onboarding } from './components/Onboarding'
import { storageKeys } from './config/storage'
import { GettingStartedModal } from './components/GettingStartedModal'
import { GettingStartedWidget } from './components/GettingStartedWidget'
import { AddToHomeHint } from './components/AddToHomeHint'
import { Seo } from './components/Seo'
import { AppMobileNav } from './layout/AppMobileNav'
import { prefetchFitRewardSlot } from './config/fitRewardUrl'

function AppShell() {
  const s = useSession()
  const loc = useLocation()
  const authOnly = !s.isAuthed && loc.pathname === '/'

  if (authOnly) {
    return (
      <div id="authView">
        <Outlet />
      </div>
    )
  }

  return (
    <>
      <AppHeader />
      <main>
        <Outlet />
      </main>
      <AppMobileNav />
      <AppFooter />
    </>
  )
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const s = useSession()
  if (!s.isAuthed) return <Navigate to="/" replace />
  return <>{children}</>
}

function FeedHome() {
  const s = useSession()
  if (!s.isAuthed) return <AuthPage />
  return (
    <FeedMoodProvider>
      <div id="homeView" className="main-content">
        <FeedPage />
      </div>
      <aside className="sidebar" id="sidebar">
        <GettingStartedWidget />
        <AddToHomeHint />
      </aside>
    </FeedMoodProvider>
  )
}

function FeedLenta() {
  return (
    <FeedMoodProvider>
      <div id="homeView" className="main-content">
        <FeedPage guestLenta />
      </div>
      <aside className="sidebar" id="sidebar">
        <GettingStartedWidget />
        <AddToHomeHint />
      </aside>
    </FeedMoodProvider>
  )
}

function TestsShell() {
  return (
    <div id="testsView" className="main-content tests-shell">
      <Outlet />
    </div>
  )
}

export default function App() {
  const s = useSession()
  const [welcomeOpen, setWelcomeOpen] = useState(false)
  const [onboardingOpen, setOnboardingOpen] = useState(false)
  const [gettingStartedOpen, setGettingStartedOpen] = useState(false)

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem(storageKeys.hasSeenOnboarding)
    if (!hasSeenOnboarding) setOnboardingOpen(true)

    const hasSeenWelcome = localStorage.getItem(storageKeys.welcomeSeen)
    if (!hasSeenWelcome) setWelcomeOpen(true)
  }, [])

  useEffect(() => {
    void prefetchFitRewardSlot()
  }, [])

  useEffect(() => {
    if (!s.isAuthed) return
    const seen = localStorage.getItem(storageKeys.gettingStartedSeen)
    const just = localStorage.getItem(storageKeys.justRegistered)
    if (!seen && just) {
      setGettingStartedOpen(true)
    }
  }, [s.isAuthed])

  return (
    <HashRouter>
      <Seo />
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<FeedHome />} />
          <Route path="/lenta" element={<FeedLenta />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/register" element={<AuthPage />} />
          <Route path="/tests" element={<TestsShell />}>
            <Route index element={<TestsHubPage />} />
            <Route path="emotions" element={<EmotionTestPage />} />
            <Route path="mbti" element={<MbtiTestPage />} />
          </Route>
          <Route
            path="/settings"
            element={
              <RequireAuth>
                <SettingsPage />
              </RequireAuth>
            }
          />
          <Route
            path="/admin"
            element={
              <RequireAuth>
                <AdminPage />
              </RequireAuth>
            }
          />
          <Route path="/profile/:username" element={<ProfilePage />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      <WelcomeModal open={welcomeOpen} onClose={() => setWelcomeOpen(false)} />
      <Onboarding
        open={onboardingOpen}
        onDone={() => {
          setOnboardingOpen(false)
          document.body.classList.remove('onboarding-active')
        }}
      />
      <GettingStartedModal open={gettingStartedOpen} onClose={() => setGettingStartedOpen(false)} />
    </HashRouter>
  )
}
